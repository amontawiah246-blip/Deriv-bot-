// The three price-action engines. Pure functions: candles in, verdict out. Every function reads CLOSED candles only,
// and reads nothing after index i (no look-ahead).
//
//  1. wickSweep      your original rule (ported 1:1 from bridge/engines/wick_sweep_engine.py, checked against it in the tests):
//                    a candle wicks past the previous candle's extreme, its body stays inside, then the context check decides TAKE or SKIP.
//  2. continuation   sweep + 2: the sweeper candle, then TWO more candles closing the same colour. Trade the NEXT candle's open, same direction.
//  3. momentum       three strong-bodied candles in a row, no sweep needed. Trade the NEXT candle's open, same direction.

export interface C { time: number; open: number; high: number; low: number; close: number }
export type Side = 'BUY' | 'SELL';
export type EngineName = 'sweep' | 'continuation' | 'momentum';

export interface Verdict {
  engine: EngineName;
  side: Side;
  ok: boolean;                 // true = TAKE, false = SKIP
  block: string | null;        // why it was skipped
  notes: string[];
  entry: number;               // close of the signal candle (reference price)
  sweptLevel: number;          // the extreme that was swept (or the momentum start level)
  from: number;                // index of the first candle that belongs to the pattern (for highlighting)
  signalIndex: number;         // index of the last candle of the pattern (the candle that just closed)
  tradeAtNextOpen: boolean;    // continuation + momentum: the trade opens on the next candle
}

const EPS = 1e-12;
const range = (c: C) => Math.max(c.high - c.low, EPS);
const body = (c: C) => Math.abs(c.close - c.open);
const bodyRatio = (c: C) => body(c) / range(c);
const mirror = (c: C): C => ({ time: c.time, open: -c.open, high: -c.low, low: -c.high, close: -c.close });

/** A broker "filler" candle (no movement at all) is not real price action. Windows containing one are not evaluated. */
export const isFlat = (c: C) => c.open === c.high && c.high === c.low && c.low === c.close;

// ------------------------------------------------------------------------------------------------ 1. wick sweep
export interface WickParams { lookback: number; minEvidence: number; maxStrength: number; strongBody: number; wickRatio: number }
export const WICK_DEFAULTS: WickParams = { lookback: 6, minEvidence: 2, maxStrength: 0.5, strongBody: 0.6, wickRatio: 0.4 };
const wickWindow = (p: WickParams) => p.lookback + 3;
const SELL_NOTES: Record<string, string> = { 'low swept and bought back': 'high swept and sold back' };

function checkLong(cs: C[], p: WickParams): { ok: boolean; block: string | null; notes: string[] } | null {
  const i = cs.length - 1;
  if (i < wickWindow(p) - 1) return null;
  const cur = cs[i], sw = cs[i - 1];
  if (!(sw.close < sw.open && cur.close > cur.open)) return null;      // swept candle bearish, sweeper bullish
  if (!(cur.low < sw.low)) return null;                                // the wick goes below the swept low
  if (Math.min(cur.open, cur.close) < sw.low) return null;             // but the BODY stays at or above it

  const zone = cs.slice(i - 1 - p.lookback, i);
  let tried = 0, firm = 0;
  const notes: string[] = [];
  zone.forEach((c, k) => {
    const pv = k ? zone[k - 1] : zone[0];
    const r = range(c);
    const lw = (Math.min(c.open, c.close) - c.low) / r;
    const b = Math.abs(c.close - c.open) / r;
    if (lw >= p.wickRatio) { tried++; notes.push('wick rejection'); }
    else if (c.close > c.open && b >= p.strongBody) { tried++; notes.push('strong push'); }
    else if (c.low < pv.low && c.close > pv.close) { tried++; notes.push('low swept and bought back'); }
    if (c.close < c.open && b >= p.strongBody && c.close <= c.low + 0.2 * r) firm++;
  });
  let strength = firm / zone.length;
  const swr = range(sw);
  if (Math.abs(sw.close - sw.open) / swr >= 0.8 && sw.close <= sw.low + 0.1 * swr) strength += 0.25;

  if (tried < p.minEvidence) return { ok: false, block: 'initiating side never really tried', notes };
  if (strength > p.maxStrength) return { ok: false, block: 'opposing side still in firm control', notes };
  return { ok: true, block: null, notes };
}

export function detectWickSweep(cs: C[], i: number, p: WickParams = WICK_DEFAULTS): Verdict | null {
  const w = wickWindow(p);
  if (i < w - 1 || i >= cs.length) return null;
  const win = cs.slice(i - w + 1, i + 1);
  const make = (side: Side, r: { ok: boolean; block: string | null; notes: string[] }, level: number): Verdict => ({
    engine: 'sweep', side, ok: r.ok, block: r.block, notes: [...new Set(r.notes)], entry: cs[i].close, sweptLevel: level,
    from: i - 1, signalIndex: i, tradeAtNextOpen: false,
  });
  const buy = checkLong(win, p);
  if (buy) return make('BUY', buy, win[w - 2].low);
  const sell = checkLong(win.map(mirror), p);
  if (sell) return make('SELL', { ...sell, notes: sell.notes.map((n) => SELL_NOTES[n] ?? n) }, win[w - 2].high);
  return null;
}

// ------------------------------------------------------------------------------------------------ 2. sweep continuation
export interface ContParams { minBody: number }
/** minBody: a confirm candle must have a body of at least this share of its range to count as "red" or "green" (a doji is not a colour). */
export const CONT_DEFAULTS: ContParams = { minBody: 0.2 };

/** Signal candle = i, the SECOND confirming candle. Pattern = [prior, sweeper, confirm 1, confirm 2]. Trade = next candle's open. */
export function detectContinuation(cs: C[], i: number, p: ContParams = CONT_DEFAULTS): Verdict | null {
  if (i < 3 || i >= cs.length) return null;
  const four = cs.slice(i - 3, i + 1);
  const bull = (q: C[]) => {
    const [pre, sw, a, b] = q;
    if (!(pre.close < pre.open)) return false;                         // prior candle red
    if (!(sw.close > sw.open && sw.low < pre.low)) return false;       // green sweeper wicks below the prior low
    if (Math.min(sw.open, sw.close) < pre.low) return false;           // body stays inside (wick sweep only)
    return [a, b].every((c) => c.close > c.open && bodyRatio(c) >= p.minBody);   // two more green candles
  };
  let side: Side | null = null;
  if (bull(four)) side = 'BUY';
  else if (bull(four.map(mirror))) side = 'SELL';
  if (!side) return null;

  const [pre, , , b] = four;
  const sellSide = side === 'SELL';
  const colour = sellSide ? 'red' : 'green';
  return {
    engine: 'continuation', side, ok: true, block: null,
    notes: [
      sellSide ? 'red candle swept the high of the green candle' : 'green candle swept the low of the red candle',
      `next two candles closed ${colour}`,
      'trade on the next candle open',
    ],
    entry: b.close, sweptLevel: sellSide ? pre.high : pre.low, from: i - 3, signalIndex: i, tradeAtNextOpen: true,
  };
}

// ------------------------------------------------------------------------------------------------ 3. momentum
export interface MomParams { strongBody: number; lookback: number }
export const MOM_DEFAULTS: MomParams = { strongBody: 0.6, lookback: 10 };

/** Signal candle = i, the THIRD candle. Needs three same-colour candles with big bodies that also step in one direction.
 *  "Big" = body is at least 60% of its range AND the three bodies are at least as large as the market's recent average body. */
export function detectMomentum(cs: C[], i: number, p: MomParams = MOM_DEFAULTS): Verdict | null {
  if (i < p.lookback + 2 || i >= cs.length) return null;
  const t = cs.slice(i - 2, i + 1);
  const up = t.every((c) => c.close > c.open);
  const down = t.every((c) => c.close < c.open);
  if (!up && !down) return null;
  if (!t.every((c) => bodyRatio(c) >= p.strongBody)) return null;
  const stepping = up ? t[1].close > t[0].close && t[2].close > t[1].close : t[1].close < t[0].close && t[2].close < t[1].close;
  if (!stepping) return null;

  const prior = cs.slice(i - 2 - p.lookback, i - 2);
  const avgPrior = prior.reduce((s, c) => s + body(c), 0) / prior.length;
  const avgNow = t.reduce((s, c) => s + body(c), 0) / 3;
  if (!(avgNow >= avgPrior)) return null;

  const side: Side = up ? 'BUY' : 'SELL';
  return {
    engine: 'momentum', side, ok: true, block: null,
    notes: [`3 strong ${up ? 'green' : 'red'} candles in a row`, 'big bodies, small wicks', 'trade on the next candle open'],
    entry: t[2].close, sweptLevel: t[0].open, from: i - 2, signalIndex: i, tradeAtNextOpen: true,
  };
}

/** Everything that fires on closed candle i. */
export function detectAll(cs: C[], i: number): Verdict[] {
  const out: Verdict[] = [];
  const w = detectWickSweep(cs, i); if (w) out.push(w);
  const c = detectContinuation(cs, i); if (c) out.push(c);
  const m = detectMomentum(cs, i); if (m) out.push(m);
  return out;
}
